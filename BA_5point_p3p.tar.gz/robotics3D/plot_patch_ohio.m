function [im] = get_patch_ohio(px)

